function submitform(){  
 var name = document.forms["rform"]["fname"].value;
 var last = document.forms["rform"]["lname"].value;
 var addr = document.forms["rform"]["address"].value;
 var cty =  document.forms["rform"]["city"].value;
    if (name == "") {
      alert ("First Name cannot be blank.");
      document.rform.fname.focus();
      return false;
    } else if (last == "") {
      alert ("Last Name cannot be blank.");
      document.rform.lname.focus();
      return false;
      }
    
else if (addr == "") {
      alert ("Address cannot be blank.");
      document.rform.address.focus();
      return false;
      }
 else if (cty == "") {
      alert ("City cannot be blank.");
      document.rform.city.focus();
      return false;
      }
       
}



